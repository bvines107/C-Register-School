﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace School
{
  
    public class school
    {
        static void Main(string[] args)
        {

        }
        //declaring Varable
        public string Name { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Zip { get; set; }
        public string PhoneNumber { get; set; }

        //create private string for twite
        private string _twitterAddress;

        //using getters-setters to set and access the private twitter address variable
        public string twitterAddress
        {
            get
            {
                return _twitterAddress;
            }

            set
            {
                if (value.StartsWith("@"))
                {
                    _twitterAddress = value;
                }
                else
                {
                    throw new Exception("twitter name must start with @");
                }
            }

        }

        //constructor to initialize name and phone number
        public school()
        {
            Name = "Untitled School";
            PhoneNumber = "555-1234";
        }

      

        //method to out put the name, address, etc variables with the user clicks submit.
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(Name);
            sb.AppendLine(Address);
            sb.AppendLine(City);
            sb.Append(", ");
            sb.Append(State);
            sb.Append(", ");
            sb.Append(Zip);
            sb.Append(" ");
            sb.AppendLine(PhoneNumber);
            sb.AppendLine(_twitterAddress);
            

            return sb.ToString();
        }
    }

}
